# Instructions

To run python script either execute `./run.sh`  or run `make all`

The shell script will install the dependencies by default. Using the make file will build a docker image,  then run the python script.

## Dependencies

numpy
requests
logging
argparse

docker is required if you use the make file

## Improvements 

Maybe add concurrency
 
## Issues

Had to look up standard deviation and reeducate myself 

## Time look

~2 hours,  worked on it on and off when I had time

